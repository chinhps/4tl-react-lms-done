export const classesSelector = (state) => state.classes.listClasses;
export const userSelector = (state) => state.user.user;
export const courseStudentSelector = (state) => state.courseStudent;
export const globalSelector = (state) => state.global;
