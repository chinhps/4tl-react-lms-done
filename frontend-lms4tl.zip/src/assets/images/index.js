import logo from './4TL_Logo_png.png';
import user from './user.png';

export {
    logo, 
    user
}