export { default as ProtectedAuth } from './auth';
